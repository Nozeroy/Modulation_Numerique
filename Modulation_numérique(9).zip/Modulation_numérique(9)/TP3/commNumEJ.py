#!/usr/bin/env python3.10

import numpy as np
import matplotlib.pyplot as plt
from scapy.all import *
import scipy
       

class Modem:
    def __init__(self, ModType, NbSymboles, bits):
        """
        Contructeur de la classe

        Parametres :
            ModType : type de modulation, PAM, ASK, PSK ou QAM
            NbSymboles : nombre de symboles de la modulation. 2, 4 ou 8 pour PAM ou ASK, 4 pour PSK et 16 pour QAM 
            bits : tableau de bits numpy       
        """
        self.modtype = ModType
        self.nsymb = NbSymboles
        self.mod = (ModType, NbSymboles)
        if ModType == 'PAM' or ModType == 'ASK':
            self.symb_type = 'reel'
        else:
            self.symb_type = 'complexe'
        self.bits = bits
        self.bits_par_symb = int(np.log2(self.nsymb))
        self.symbs_num = bits.reshape(int(len(bits)/self.bits_par_symb), self.bits_par_symb)
        if (self.nsymb & (self.nsymb-1) == 0) and self.nsymb != 0:
            self.bit_par_symb = int(np.log2(self.nsymb))
        else:
            raise ValueError('La deuxième valeur qui correspond au nombre de symboles doit être une puissance de 2 : 2, 4, 8, 16, 32, 64, ...')

    def create_MP(self, amplitude, phase_origine=0):
        """
        Fonction en charge de créer la table de mapping de chaque modulation et appelée par la fonction mapping.
    
        Paramètres :
        amplitude : amplitude maximale des symboles
        phase_origine : phase d'origine pour la rotation de la constellation (par défaut 0)
    
        Retourne :
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        match self.mod:
            case ('PAM', 2) | ('ASK', 2):
                mapping_table = {(0,): -1, (1,): 1}
            case ('PAM', 4) | ('ASK', 4):
                mapping_table = {(0, 0): -3, (0, 1): -1, (1, 0): 1, (1, 1): 3}
            case ('PAM', 8) | ('ASK', 8):
                mapping_table = {(0, 0, 0): -7, (0, 0, 1): -5, (0, 1, 0): -3, (0, 1, 1): -1,
                                 (1, 0, 0): 1, (1, 0, 1): 3, (1, 1, 0): 5, (1, 1, 1): 7}
            case ('PSK', 4):  # Changement de 4PSK à PSK
                # Constellation QPSK sans rotation
                # Définition de la constellation QPSK
                constel_QPSK = np.array([-1+1j, 1+1j, -1-1j, 1-1j])

                # Appliquer la rotation de la constellation en fonction de la phase d'origine
                constel_QPSK_rotated = constel_QPSK * np.exp(1j * phase_origine)

                # Créer le dictionnaire de mapping
                mapping_table = {
                    (0, 0): constel_QPSK_rotated[0],
                    (0, 1): constel_QPSK_rotated[1],
                    (1, 0): constel_QPSK_rotated[2],
                    (1, 1): constel_QPSK_rotated[3]
                }
            case _:
                mapping_table = None
                print(f'La modulation {self.nsymb}{self.modtype} n\'est pas implémentée')

        for key in mapping_table.keys():
            mapping_table[key] = mapping_table[key] * amplitude / (self.nsymb - 1)

        self.mapping_table = mapping_table
        return mapping_table



    def mapping(self, amplitude, phase_ori= np.pi/4):
        """
        Fonction en charge d'effectue le mapping entre les symboles numériques et les symboles de modulation
    
        Parametres
        ----------
        amplitude : amplitude maximale des symboles de modulation pour une modulation PAM ou ASK,
                    amplitude max de la sinusoide pour une modulation PSK et amplitude max de I
                    et Q pour une modulation QAM
        phase_ori : utilisé seulement pour la modulation QPSK, phase à l'origine du premier
                    symbole (par défaut = pi/4)
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        self.mapping_table = self.create_MP(amplitude, phase_ori)
        symbs_mod=np.array([self.mapping_table[tuple(symb)] for symb in self.symbs_num])
        return(symbs_mod)
    
    def filtre_MF(self, symboles_mod, NbEchParSymb, type='rectangular'):
        self.nech = NbEchParSymb
        if type == 'rectangular':
            signal_PAM=np.repeat(symboles_mod,NbEchParSymb)
        elif type == 'manchester':
            if NbEchParSymb % 2 == 0:
                entrelace = np.empty((2*symboles_mod.size,), dtype=symboles_mod.dtype)
                entrelace[0::2] = symboles_mod
                entrelace[1::2] = -symboles_mod
                signal_PAM=np.repeat(entrelace,int(NbEchParSymb/2))
            else :
                raise ValueError('Le nombre d\'échantillons par symbole doit être un multiple de 2')
        return(signal_PAM)

    def downconv(self, signal, fp, te, symb_type = 'complexe'):
        t = np.arange(0,len(signal)*te,te)
        reel=np.cos(2*np.pi*fp*t)
        im = np.sin(2*np.pi*fp*t)

        if symb_type == 'complexe':
            exp = reel-im*1j
            signal_down=exp*signal
        else :
            signal_down=reel*signal
        return(signal_down)

    def downsample(self, signal, n, offset=0):
        
        
        """
        Réduit le taux d'échantillonnage d'un signal.

        Paramètres :
        - signal : signal à traiter.
        - n : facteur de réduction du taux d'échantillonnage.
        - offset: décalage initial (par défaut 0).

        Retourne :
        - Le signal échantillonné.
        """
        if self.symb_type == 'complexe':
            signal_down=np.array([], dtype=complex)
        else :
            signal_down=np.array([])
        for i in range(offset, len(signal), n):
            signal_down = np.append(signal_down,signal[i])
        return(signal_down) 

    def detection(self, symbs_rcv):
        constellation = np.array([val for val in self.mapping_table.values()])
        if self.symb_type == 'complexe':
            symbs_detect=[min(constellation, key=lambda symb_mod:abs(np.square(np.real(symbr)-
            np.real(symb_mod))+np.square(np.imag(symbr)-np.imag(symb_mod)))) for symbr in symbs_rcv]
        else :
            symbs_detect=[min(constellation, key=lambda symb_mod:abs(symbr-symb_mod)) for symbr in
            symbs_rcv]
        return(np.array(symbs_detect))

    def demapping(self, symbs_rcv):
        demapping_table = {v : k for k, v in self.mapping_table.items()}
        symbs_num=np.array([demapping_table[symb] for symb in symbs_rcv])
        bits_rcv = np.ravel(symbs_num)
        return (bits_rcv)

    def upconv(self, env_complexe, fp, te):
        #création de l'exponentielle complexe
        t=np.arange(0, len(env_complexe)*te, te)
        reel=np.cos(2*np.pi*fp*t)
        im=np.sin(2*np.pi*fp*t)
        exp=reel+im*1j
        #translation de fréquence upconversion
        sig_analytique = env_complexe*exp
        sig_module=np.real(sig_analytique)
        return(sig_module)
    
    def filtre_rcv(self, signal, fe=100, fc=10, type="butter", ordre=3):
        if type == "butter":
            b, a = scipy.signal.butter(ordre*2, 2 * fc / fe, 'low')
            signal_filtre = scipy.signal.filtfilt(b, a, signal)
        else: 
            raise ValueError("Le type de filtre doit être 'butter'.")
        return signal_filtre
    
class Test :
    
    def print (self):
        print('test')

class Mesures:
    def __init__(self, signal, fe):
        """
        Initialisation avec le signal et la fréquence d'échantillonnage.
        Paramètres :
        - signal : signal à analyser (tableau numpy)
        - fe : fréquence d'échantillonnage en Hz
        le "fe" n'est pas obligatoire dans le constructeur, il est donc à retirer s'il y'a des problèmes
        """
        self.signal = signal
        self.fe = fe

    def DSP(self, aff='mono', unit='dBm'):
        """
        Calcul et affichage de la DSP du signal selon le type d'affichage monolatéral ou bilatéral.
        
        Paramètres :
        - aff : 'mono' pour monolatéral, 'bila' pour bilatéral
        - unit : unité pour l'affichage, par défaut en 'dBm'
        """
        N = len(self.signal)
        S = 1 / N * np.fft.fft(self.signal)  # FFT du signal
        
        if aff == 'mono':
            # FFT monolatérale
            S_mono = np.concatenate((S[0:1], 2 * S[1:N // 2]))
            f = np.linspace(0, self.fe / 2, N // 2)
        elif aff == 'bila':
            # FFT bilatérale
            S = np.fft.fftshift(S)
            f = np.linspace(-self.fe / 2, self.fe / 2, N)

        # Calcul de la densité spectrale de puissance (DSP)
        S_mag = np.abs(S_mono) if aff == 'mono' else np.abs(S)
        S_eff = S_mag / np.sqrt(2)  # Tension efficace

        # Conversion en dBm si demandé
        if unit == 'dBm':
            S_dBm = 10 * np.log10(np.square(S_eff) / 50 * 1000)
            dsp = S_dBm
        elif unit == 'eff':
            dsp = S_eff

        # Création du graphique
        fig, ax = plt.subplots(figsize=(15, 4))
        ax.plot(f, dsp)
        ax.grid(True)
        ax.set_title('Densité spectrale de puissance (DSP)', fontsize=18)
        ax.set_xlabel('Fréquence (Hz)')
        ax.set_ylabel(f'Puissance ({unit})')

        plt.show()
    
    
    def PAM4(nsymb):
        # Table de mapping PAM4
        mapping_PAM4 = {
            (0, 0): -3,
            (0, 1): -1,
            (1, 0): 1,
            (1, 1): 3
        }

        # Génération de la séquence binaire aléatoire
        bits_par_symb = 2  # PAM4 correspond à 2 bits par symbole
        nbits = nsymb * bits_par_symb
        bits = np.random.binomial(1, 0.5, nbits)

        # Mise sous forme de symboles numériques (paires de bits)
        symbs_num = bits.reshape(nsymb, bits_par_symb)

        print(f'Le vecteur bits au format {bits.shape} est : \n {bits} \n')
        print(f'La matrice des symboles numériques avec 1 symbole par ligne au format {symbs_num.shape} est : \n {symbs_num}')

        # Mapping des symboles numériques vers les niveaux PAM4
        symbs_mod = np.array([mapping_PAM4[tuple(symb)] for symb in symbs_num])

        print(f'Le vecteur des symboles de modulation réels est :\n{symbs_mod}')

        return symbs_mod

    @staticmethod
    def diagramme_constellation(symbs_mod, taille_fenetre=8, titre="Diagramme de constellation"):
        # Création de la figure
        fig, ax = plt.subplots(figsize=(6, 6))

        # Affichage des symboles sur le diagramme de constellation
        ax.plot(np.real(symbs_mod), np.imag(symbs_mod), 'o', mew=6)

        # Paramétrage des limites et des axes
        ax.set_xlim([-taille_fenetre/2, taille_fenetre/2])
        ax.set_ylim([-taille_fenetre/2, taille_fenetre/2])
        ax.grid()

        # Labels et titre
        ax.set_xlabel('Partie réelle des symboles de modulation', fontsize=16)
        ax.set_ylabel('Partie imaginaire des symboles de modulation', fontsize=16)
        ax.set_title(titre, fontsize=16)
        ax.xaxis.set_tick_params(labelsize=14)
        ax.yaxis.set_tick_params(labelsize=14)

        # Affichage du diagramme
        plt.show()

    def plot_constellation(self, symbols, window_size=8, title="Diagramme de constellation"):
        """
        Affiche le diagramme de constellation pour les symboles fournis.
        
        Paramètres :
        - symbols : array numpy des symboles de modulation.
        - window_size : taille de la fenêtre carrée (par défaut 8).
        - title : titre de la fenêtre (par défaut "Diagramme de constellation").
        """
        plt.figure(figsize=(window_size, window_size))
        plt.scatter(np.real(symbols), np.imag(symbols), marker='o', color='blue')
        plt.title(title)
        plt.xlabel('Partie réelle des symboles de modulation')
        plt.ylabel('Partie imaginaire des symboles de modulation')
        plt.axhline(0, color='gray', lw=0.5, ls='--')
        plt.axvline(0, color='gray', lw=0.5, ls='--')
        plt.grid()
        plt.xlim(np.min(np.real(symbols)) - 1, np.max(np.real(symbols)) + 1)  # Ajuster les limites x
        plt.ylim(np.min(np.imag(symbols)) - 1, np.max(np.imag(symbols)) + 1)  # Ajuster les limites y
        plt.show()

class Source:

    @staticmethod
    def random(nb_bits):

        bits=np.random.binomial(1,0.5,nb_bits)
        print(bits)
        return bits

    @staticmethod
    def ICMP(MACd, MACs, IPd, IPs, icmp_type):

        icmp_type_val = 8 if icmp_type == 'request' else 0
        
        frame_tr= Ether(src=MACs, dst=MACd)/IP(src=IPs, dst = IPd)/ICMP(type=icmp_type_val)
        print(f'les données associées à la trame au format hexadécimal sont :\n',frame_tr)
        print(f'mais c\' est un objet de type Scapy : {type(frame_tr)}.',end='')
        print(f'On peut le convertir en un objet de types bytes : {type(bytes(frame_tr))}\n')

        # Conversion de la trame en une liste d'entiers entre 0 et 255

        frame_dec = list(bytes(frame_tr))
        print(f'En convertissant l objet bytes en une liste, on obtient une liste d entier : \n',frame_dec)

        # Conversion en array NumPy
        frame_np = np.array(frame_dec, dtype=np.uint8)
        print(f' et maintenant sous, la forme d\'un array numpy : \n',frame_np)
    
        # Conversion sous la forme d'un liste en binaire

        frame_bin = []

        for val in frame_dec :
            # la fonction format convertit un str au format désiré, ici binaire "b" en remplissant de 0 pour avoir 8 bits
            z = format(val, "08b")
            # sépare le mot de code sur 8 bits en une liste de 8 éléments et l'ajoute à la liste "frame_bin"
            frame_bin += list(z)
        print('\n les données associées à la trame au format binaire dans une liste de str : \n', frame_bin)

        # Conversion en un tableau numpy : chaque élément correspondant à une str est converti en un entier int

        bits = np.array([int(x) for x in frame_bin])
        print('\n les données associées à la trame au format binaire dans un tableau numpy : \n',bits)
        return bits


class Canal:

    def awgn(signal, mean, std):
        num_samples = len(signal)
        noise = np.random.normal(mean, std, size=num_samples)
        signal_bruite=signal+noise
        return(signal_bruite)
    

class PLT:

    def __init__(self, Signal):
        self.signal = Signal
    
    @staticmethod
    def show(size, x, y, drawstyle, title, xlabel, ylabel):
        plt.figure(figsize=size)
        plt.plot(x, y, drawstyle=drawstyle)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.grid(True)
        plt.show()

class AWGN:

    @staticmethod
    def awgn(signal, mean, std) :
        num_samples = len(signal)
        noise = np.random.normal(mean, std, size=num_samples)
        signal_bruite=signal+noise
        return(signal_bruite)