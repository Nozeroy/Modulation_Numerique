#!/usr/bin/env python3.10

import numpy as np
import matplotlib.pyplot as plt
from scapy.all import *
import cmath

class Modem :
    """
        Classe permettant d'implémenter un MOdulateur/DEModulateur PAM ou ASK (2,4,8), QPSK et 16QAM.
    """

    def __init__(self, ModType, NbSymboles, bits):
        """
        Contructeur de la classe

        Parametres :
            ModType : type de modulation, PAM, ASK, PSK ou QAM
            NbSymboles : nombre de symboles de la modulation. 2, 4 ou 8 pour PAM ou ASK, 4 pour PSK et 16 pour QAM 
            bits : tableau de bits numpy       
        """
        self.modtype = ModType
        self.nsymb = NbSymboles
        self.mod = (ModType, NbSymboles)
        if ModType == 'PAM' or ModType == 'ASK' :
            self.symb_type = 'reel'
        else : 
            self.symb_type = 'complexe'
        self.bits = bits
        self.bits_par_symb = int(np.log2(self.nsymb))
        self.symbs_num = bits.reshape(int(len(bits)/self.bits_par_symb), self.bits_par_symb)
        if (self.nsymb & (self.nsymb-1) == 0) and self.nsymb != 0 :
            self.bit_par_symb=int(np.log2(self.nsymb))
        else :
            raise ValueError('La deuxième valeur qui correspond au nombre de symboles \
            doit être une puissance de 2 : 2, 4, 8, 16, 32, 64, ...')
            
    def create_MP(self, amplitude, phase_origine=0):
        """
        Fonction en charge de créer la table de mapping de chaque modulation et appelée par la fonction
        mapping

        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        match self.mod:
            case ('PAM', 2) | ('ASK', 2):
                mapping_table = {(0,): -1,
                                (1,): 1}
            case ('PAM', 4) | ('ASK', 4):
                mapping_table = {(0, 0): -3,
                                (0, 1): -1,
                                (1, 0): 1,
                                (1, 1): 3}
            case ('PAM', 8) | ('ASK', 8):
                mapping_table = {(0, 0, 0): -7,
                                (0, 0, 1): -5,
                                (0, 1, 0): -3,
                                (0, 1, 1): -1,
                                (1, 0, 0): 1,
                                (1, 0, 1): 3,
                                (1, 1, 0): 5,
                                (1, 1, 1): 7}
            case ('PSK', 4):
                # Define 4PSK mapping
                mapping_table = {(0, 0): cmath.exp(1j * (phase_origine + math.pi/4)),  # 45 degrees
                                (0, 1): cmath.exp(1j * (phase_origine + 3 * math.pi/4)),  # 135 degrees
                                (1, 0): cmath.exp(1j * (phase_origine + -3 * math.pi/4)),  # -135 degrees
                                (1, 1): cmath.exp(1j * (phase_origine + -math.pi/4))}  # -45 degrees
            case _:
                mapping_table = None
                print(f'La modulation {self.nsymb}{self.modtype} n\'est pas implémentée')
                return None

        # Adjust for amplitude and normalization for non-PSK modulation
        if self.mod != ('PSK', 4):
            for key in mapping_table.keys():
                mapping_table[key] = mapping_table[key] * amplitude / (self.nsymb - 1)
        else:
            # Rotate the constellation by phase_origine and scale by amplitude
            for key in mapping_table.keys():
                mapping_table[key] *= amplitude

        self.mapping_table = mapping_table
        return mapping_table

    def mapping(self, amplitude, phase_ori= np.pi/4):
        """
        Fonction en charge d'effectue le mapping entre les symboles numériques et les symboles de modulation
    
        Parametres
        ----------
        amplitude : amplitude maximale des symboles de modulation pour une modulation PAM ou ASK,
                    amplitude max de la sinusoide pour une modulation PSK et amplitude max de I
                    et Q pour une modulation QAM
        phase_ori : utilisé seulement pour la modulation QPSK, phase à l'origine du premier
                    symbole (par défaut = pi/4)
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        self.mapping_table = self.create_MP(amplitude, phase_ori)
        symbs_mod=np.array([self.mapping_table[tuple(symb)] for symb in self.symbs_num])
        return(symbs_mod)

    def filtre_MF(self, symboles_mod, NbEchParSymb, type='rectangular'):
        self.nech = NbEchParSymb
        if type == 'rectangular':
            signal_PAM=np.repeat(symboles_mod,NbEchParSymb)
        elif type == 'manchester':
            if NbEchParSymb % 2 == 0:
                entrelace = np.empty((2*symboles_mod.size,), dtype=symboles_mod.dtype)
                entrelace[0::2] = symboles_mod
                entrelace[1::2] = -symboles_mod
                signal_PAM=np.repeat(entrelace,int(NbEchParSymb/2))
            else :
                raise ValueError('Le nombre d\'échantillons par symbole doit être un multiple de 2')
        return(signal_PAM)
    
    def downsample(self, signal, downsampling, offset = 0):
        if self.symb_type == 'complexe':
            signal_down=np.array([], dtype=complex)
        else :
            signal_down=np.array([])
            for i in range(offset, len(signal), downsampling):
                signal_down = np.append(signal_down,signal[i])
        return(signal_down)
    
    def detection(self, symbs_rcv):
        constellation = np.array([val for val in self.mapping_table.values()])
        if self.symb_type == 'complexe':
            symbs_detect=[min(constellation, key=lambda symb_mod:abs(np.square(np.real(symbr)-
            np.real(symb_mod))+np.square(np.imag(symbr)-np.imag(symb_mod)))) for symbr in symbs_rcv]
        else :
            symbs_detect=[min(constellation, key=lambda symb_mod:abs(symbr-symb_mod)) for symbr in
            symbs_rcv]
        return(np.array(symbs_detect))

    def demapping(self, symbs_rcv) :
        demapping_table = {v : k for k, v in self.mapping_table.items()}
        symbs_num=np.array([demapping_table[symb] for symb in symbs_rcv])
        bits_rcv=np.ravel(symbs_num)
        return (bits_rcv)

    def upconv(self, env_complexe, fp, te):
        #Création de l'exponentielle complexe
        t=np.arange(0,len(env_complexe)*te,te)
        reel=np.cos(2*np.pi*fp*t)
        im=np.sin(2*np.pi*fp*t)
        exp=reel+im*1j
        #Translation de fréquence upconversion
        sig_analytique= env_complexe*exp
        sig_module=np.real(sig_analytique)
        return(sig_module)
    
class Mesure :
    """
    Classe permettant d'implémenter un Modulateur/DEModulateur PAM ou ASK (2,4,8), QPSK et 16QAM.
    """

    def __init__(self, Signal):
        self.signal = Signal

    def dsp(self, fe, type_affichage='mono', unite='Veff'):
        N = len(self.signal)
        
        fft_signal = 1/N * np.fft.fftshift(np.fft.fft(self.signal))
        
        # Module de la FFT
        dsp = np.abs(fft_signal)
        
        # Densité spectrale de tension efficace (Veff)
        dsp_eff = dsp / np.sqrt(2)
        
        # Création du vecteur de fréquences
        freqs = np.arange(-fe/2, fe/2, fe/N)
        
        if type_affichage == 'mono':
            dsp_eff = dsp_eff[N//2:]
            freqs = freqs[N//2:]

        if unite == 'dBm':
            dsp_dBm = 10 * np.log10(np.square(dsp_eff) / 50 * 1000)
            dsp_to_plot = dsp_dBm
            ylabel = 'DSP (dBm)'
        else:
            dsp_to_plot = dsp_eff
            ylabel = 'DSP (Veff)'

        plt.figure(figsize=(10, 6))
        plt.plot(freqs, dsp_to_plot, label='DSP du signal')
        
        plt.title('Densité Spectrale de Puissance (DSP)', fontsize=14)
        plt.xlabel('Fréquence (Hz)', fontsize=12)
        plt.ylabel(ylabel, fontsize=12)
        
        plt.grid(True)
        plt.legend()
        plt.show()
    
    def constellation(self, taille = 8, titre = "Diagramme de Constellation"):
        fig, ax = plt.subplots(figsize = (taille, taille))
        plt.plot(np.real(self.signal), np.imag(self.signal), 'o', mew=2)
        ax.grid()
        ax.set_ylabel(' Partie imaginaire des \n symboles de modulation', fontsize=16)
        ax.set_xlabel('Partie réelle des symboles de modulation', fontsize=16)
        ax.set_title(titre, fontsize=16)
        ax.xaxis.set_tick_params(labelsize=14)
        ax.yaxis.set_tick_params(labelsize=14)
        plt.show()
        
class Source :

    def random(bits):
        tab = np.random.binomial(1, 0.5, bits)
        return np.array([int(x) for x in tab])
    
    def icmp(ipDest, ipSource='192.168.1.1', macSource='00:01:02:03:04:05', macDest='06:07:08:09:0A:0B', type='echo-request'):
        frame_tr=Ether(src=macSource, dst=macDest)/IP(src=ipSource, dst=ipDest)/ICMP()
        frame_dec=list(bytes(frame_tr))
        frame_bin=[]
        for val in frame_dec:
            z=format(val, "08b")
            frame_bin += list(z)
        return np.array([int(x) for x in frame_bin])

class PLT:

    def __init__(self, Signal):
        self.signal = Signal
    
    @staticmethod
    def show(size, x, y, drawstyle, title, xlabel, ylabel):
        plt.figure(figsize=size)
        plt.plot(x, y, drawstyle=drawstyle)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.grid(True)
        plt.show()

class AWGN:

    @staticmethod
    def awgn(signal, mean, std) :
        num_samples = len(signal)
        noise = np.random.normal(mean, std, size=num_samples)
        signal_bruite=signal+noise
        return(signal_bruite)