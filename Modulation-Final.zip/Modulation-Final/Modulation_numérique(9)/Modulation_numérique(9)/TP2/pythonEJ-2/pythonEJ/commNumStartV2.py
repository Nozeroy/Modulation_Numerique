#!/usr/bin/env python3.10

import numpy as np
import matplotlib.pyplot as plt
       
class Modem :
    """
        Classe permettant d'implémenter un MOdulateur/DEModulateur PAM ou ASK (2,4,8), QPSK et 16QAM.
    """

    def __init__(self, ModType, NbSymboles, bits):
        """
        Contructeur de la classe

        Parametres :
            ModType : type de modulation, PAM, ASK, PSK ou QAM
            NbSymboles : nombre de symboles de la modulation. 2, 4 ou 8 pour PAM ou ASK, 4 pour PSK et 16 pour QAM 
            bits : tableau de bits numpy       
        """
        self.modtype = ModType
        self.nsymb = NbSymboles
        self.mod = (ModType, NbSymboles)
        if ModType == 'PAM' or ModType == 'ASK' :
            self.symb_type = 'reel'
        else : 
            self.symb_type = 'complexe'
        self.bits = bits
        self.bits_par_symb = int(np.log2(self.nsymb))
        self.symbs_num = bits.reshape(int(len(bits)/self.bits_par_symb), self.bits_par_symb)
        if (self.nsymb & (self.nsymb-1) == 0) and self.nsymb != 0 :
            self.bit_par_symb=int(np.log2(self.nsymb))
        else :
            raise ValueError('La deuxième valeur qui correspond au nombre de symboles \
            doit être une puissance de 2 : 2, 4, 8, 16, 32, 64, ...')
            
    def create_MP(self, amplitude, phase_ori):
        """
        Fonction en charge de créer la table de mapping de chaque modulation et applée par la fonction
        mapping
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        match self.mod:
            case ('PAM',2)| ('ASK',2) :
                mapping_table = {(0,) : -1,
                                (1,) : 1}
            case ('PAM',4)| ('ASK',4) :
                mapping_table = {(0,0) : -3,
                                (0,1) : -1,
                                (1,0) : 1,
                                (1,1) : 3}
            case ('PAM',8)| ('ASK',8) :
                mapping_table = {(0,0,0) : -7,
                                (0,0,1) : -5,
                                (0,1,0) : -3,
                                (0,1,1) : -1,
                                (1,0,0) : 1,
                                (1,0,1) : 3,
                                (1,1,0) : 5,
                                (1,1,1) : 7}   
            case _:
                mapping_table = None
                print(f'La modulation {self.nsymb}{self.modtype} n\'est pas implémentée')
        for key in mapping_table.keys() :
            mapping_table[key] = mapping_table[key] * amplitude / (self.nsymb-1)
        self.mapping_table = mapping_table
        return(mapping_table)

    def mapping(self, amplitude, phase_ori= np.pi/4):
        """
        Fonction en charge d'effectue le mapping entre les symboles numériques et les symboles de modulation
    
        Parametres
        ----------
        amplitude : amplitude maximale des symboles de modulation pour une modulation PAM ou ASK,
                    amplitude max de la sinusoide pour une modulation PSK et amplitude max de I
                    et Q pour une modulation QAM
        phase_ori : utilisé seulement pour la modulation QPSK, phase à l'origine du premier
                    symbole (par défaut = pi/4)
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        self.mapping_table = self.create_MP(amplitude, phase_ori)
        symbs_mod=np.array([self.mapping_table[tuple(symb)] for symb in self.symbs_num])
        return(symbs_mod)
    
class Test :
    
    def print (self):
        print('test')






        
class Modem3 :
    """
        Classe permettant d'implémenter un MOdulateur/DEModulateur PAM ou ASK (2,4,8), QPSK et 16QAM.
    """

    def __init__(self, ModType, NbSymboles, bits, symb_type='complexe'):
        """
        Contructeur de la classe

        Parametres :
            ModType : type de modulation, PAM, ASK, PSK ou QAM
            NbSymboles : nombre de symboles de la modulation. 2, 4 ou 8 pour PAM ou ASK, 4 pour PSK et 16 pour QAM 
            bits : tableau de bits numpy       
        """
        self.modtype = ModType
        self.nsymb = NbSymboles
        self.mod = (ModType, NbSymboles)
        if ModType == 'PAM' or ModType == 'ASK' :
            self.symb_type = 'reel'
        else : 
            self.symb_type = 'complexe'
        self.bits = bits
        self.bits_par_symb = int(np.log2(self.nsymb))
        self.symbs_num = bits.reshape(int(len(bits)/self.bits_par_symb), self.bits_par_symb)
        if (self.nsymb & (self.nsymb-1) == 0) and self.nsymb != 0 :
            self.bit_par_symb=int(np.log2(self.nsymb))
        else :
            raise ValueError('La deuxième valeur qui correspond au nombre de symboles \
            doit être une puissance de 2 : 2, 4, 8, 16, 32, 64, ...')
        self.symb_type = symb_type
            
    def create_MP(self, amplitude, phase_ori):
        """
        Fonction en charge de créer la table de mapping de chaque modulation et applée par la fonction
        mapping
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        match self.mod:
            case ('PAM',2)| ('ASK',2) :
                mapping_table = {(0,) : -1,
                                (1,) : 1}
            case ('PAM',4)| ('ASK',4) :
                mapping_table = {(0,0) : -3,
                                (0,1) : -1,
                                (1,0) : 1,
                                (1,1) : 3}
            case ('PAM',8)| ('ASK',8) :
                mapping_table = {(0,0,0) : -7,
                                (0,0,1) : -5,
                                (0,1,0) : -3,
                                (0,1,1) : -1,
                                (1,0,0) : 1,
                                (1,0,1) : 3,
                                (1,1,0) : 5,
                                (1,1,1) : 7}   
            case _:
                mapping_table = None
                print(f'La modulation {self.nsymb}{self.modtype} n\'est pas implémentée')
        for key in mapping_table.keys() :
            mapping_table[key] = mapping_table[key] * amplitude / (self.nsymb-1)
        self.mapping_table = mapping_table
        return(mapping_table)

    def mapping(self, amplitude, phase_ori= np.pi/4):
        """
        Fonction en charge d'effectue le mapping entre les symboles numériques et les symboles de modulation
    
        Parametres
        ----------
        amplitude : amplitude maximale des symboles de modulation pour une modulation PAM ou ASK,
                    amplitude max de la sinusoide pour une modulation PSK et amplitude max de I
                    et Q pour une modulation QAM
        phase_ori : utilisé seulement pour la modulation QPSK, phase à l'origine du premier
                    symbole (par défaut = pi/4)
   
        Retourne
        -------
        mapping_table : la table de mapping sous forme d'un dictionnaire
        """
        self.mapping_table = self.create_MP(amplitude, phase_ori)
        symbs_mod=np.array([self.mapping_table[tuple(symb)] for symb in self.symbs_num])
        return(symbs_mod)
    
    def filtre_MF(symboles_mod, NbEchParSymb, type):
        if type == 'rectangular':
            signal_PAM=np.repeat(symboles_mod,NbEchParSymb)
        elif type == 'manchester':
            if NbEchParSymb % 2 == 0:
                entrelace = np.empty((2*symboles_mod.size,), dtype=symboles_mod.dtype)
                entrelace[0::2] = symboles_mod
                entrelace[1::2] = -symboles_mod
                signal_PAM= np.repeat(entrelace, int(NbEchParSymb/2))

        else :
            raise ValueError('le nombre d\'échantillons par symbole doit être un multiple de 2')
        return(signal_PAM)
